import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CalendarIcon } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

interface CreateTaskDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateTask: (task: any) => void;
}

const users = [
  { id: '1', name: 'John Doe', role: 'executor' },
  { id: '2', name: 'Jane Smith', role: 'executor' },
  { id: '3', name: 'Mike Johnson', role: 'executor' },
  { id: '4', name: 'Sarah Wilson', role: 'executor' },
];

const observers = [
  { id: '5', name: 'Tom Observer', role: 'observer' },
  { id: '6', name: 'Lisa Watcher', role: 'observer' },
  { id: '7', name: 'David Monitor', role: 'observer' },
];

export function CreateTaskDialog({ isOpen, onClose, onCreateTask }: CreateTaskDialogProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assigneeId, setAssigneeId] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
  const [dueDate, setDueDate] = useState<Date>();
  const [selectedObservers, setSelectedObservers] = useState<string[]>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !assigneeId || !dueDate) {
      return;
    }

    const assignee = users.find(u => u.id === assigneeId);
    if (!assignee) return;

    const newTask = {
      id: Math.random().toString(36).substr(2, 9),
      title: title.trim(),
      description: description.trim(),
      status: 'new' as const,
      priority,
      assignee: {
        id: assignee.id,
        name: assignee.name,
      },
      reporter: {
        id: 'manager-1',
        name: 'Current Manager',
      },
      dueDate,
      createdAt: new Date(),
      observers: selectedObservers.length,
      subtasks: [], // Initialize empty subtasks array
    };

    onCreateTask(newTask);
    
    // Reset form
    setTitle('');
    setDescription('');
    setAssigneeId('');
    setPriority('medium');
    setDueDate(undefined);
    setSelectedObservers([]);
    
    onClose();
  };

  const toggleObserver = (observerId: string) => {
    setSelectedObservers(prev => 
      prev.includes(observerId)
        ? prev.filter(id => id !== observerId)
        : [...prev, observerId]
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create New Task</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Task Title *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter task title..."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide task details and requirements..."
              className="min-h-[100px]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Assignee *</Label>
              <Select value={assigneeId} onValueChange={setAssigneeId} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select assignee" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Priority</Label>
              <Select value={priority} onValueChange={(value: any) => setPriority(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Due Date *</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dueDate ? format(dueDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={dueDate}
                  onSelect={setDueDate}
                  initialFocus
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Observers (Optional)</Label>
            <div className="border rounded-lg p-3 space-y-2 max-h-32 overflow-y-auto">
              {observers.map((observer) => (
                <div key={observer.id} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id={`observer-${observer.id}`}
                    checked={selectedObservers.includes(observer.id)}
                    onChange={() => toggleObserver(observer.id)}
                    className="rounded"
                  />
                  <Label
                    htmlFor={`observer-${observer.id}`}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {observer.name}
                  </Label>
                </div>
              ))}
            </div>
            {selectedObservers.length > 0 && (
              <p className="text-sm text-muted-foreground">
                {selectedObservers.length} observer(s) selected
              </p>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={!title.trim() || !assigneeId || !dueDate}>
              Create Task
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}