import { useState } from "react";
import { TaskCard } from "./TaskCard";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Search, Filter, Plus, Grid, List } from "lucide-react";

interface Task {
  id: string;
  title: string;
  description: string;
  status: 'new' | 'in-progress' | 'review' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignee: {
    id: string;
    name: string;
    avatar?: string;
  };
  reporter: {
    id: string;
    name: string;
    avatar?: string;
  };
  dueDate: Date;
  createdAt: Date;
  attachments?: number;
  observers?: number;
}

interface TaskListProps {
  tasks: Task[];
  userRole: 'manager' | 'executor' | 'observer';
  onTaskClick: (task: Task) => void;
  onStatusChange?: (taskId: string, status: Task['status']) => void;
  onCreateTask?: () => void;
}

export function TaskList({ tasks, userRole, onTaskClick, onStatusChange, onCreateTask }: TaskListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'kanban'>('grid');

  // Filter tasks based on user role
  const getFilteredTasks = () => {
    let filteredTasks = tasks;

    // Strict role-based filtering
    if (userRole === 'executor') {
      // Executors can ONLY see tasks assigned to them
      filteredTasks = filteredTasks.filter(task => task.assignee.id === 'current-user');
    } else if (userRole === 'observer') {
      // Observers can see all tasks but cannot modify them
      filteredTasks = tasks;
    }
    // Managers can see all tasks (no filtering)

    // Search filter
    if (searchQuery) {
      filteredTasks = filteredTasks.filter(task =>
        task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.assignee.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filteredTasks = filteredTasks.filter(task => task.status === statusFilter);
    }

    // Priority filter
    if (priorityFilter !== 'all') {
      filteredTasks = filteredTasks.filter(task => task.priority === priorityFilter);
    }

    return filteredTasks;
  };

  const filteredTasks = getFilteredTasks();

  // Group tasks by status for Kanban view
  const groupedTasks = {
    'new': filteredTasks.filter(t => t.status === 'new'),
    'in-progress': filteredTasks.filter(t => t.status === 'in-progress'),
    'review': filteredTasks.filter(t => t.status === 'review'),
    'completed': filteredTasks.filter(t => t.status === 'completed')
  };

  const statusColumns = [
    { key: 'new', title: 'New', color: 'bg-blue-100 text-blue-800' },
    { key: 'in-progress', title: 'In Progress', color: 'bg-yellow-100 text-yellow-800' },
    { key: 'review', title: 'Review', color: 'bg-purple-100 text-purple-800' },
    { key: 'completed', title: 'Completed', color: 'bg-green-100 text-green-800' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl">
            {userRole === 'executor' ? 'My Tasks' : 'All Tasks'}
          </h2>
          <p className="text-muted-foreground">
            {filteredTasks.length} task{filteredTasks.length !== 1 ? 's' : ''} found
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 border rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'kanban' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('kanban')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
          {/* Only managers can create tasks */}
          {userRole === 'manager' && (
            <Button onClick={onCreateTask}>
              <Plus className="h-4 w-4 mr-2" />
              Create Task
            </Button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tasks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="review">Review</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>

          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priority</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="urgent">Urgent</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Task View */}
      {viewMode === 'grid' ? (
        /* Grid View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              userRole={userRole}
              onTaskClick={onTaskClick}
              onStatusChange={onStatusChange}
            />
          ))}
        </div>
      ) : (
        /* Kanban View */
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {statusColumns.map((column) => (
            <div key={column.key} className="space-y-4">
              <div className="flex items-center justify-between">
                <Badge className={`${column.color} px-3 py-1`}>
                  {column.title}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {groupedTasks[column.key as keyof typeof groupedTasks].length}
                </span>
              </div>
              <div className="space-y-3">
                {groupedTasks[column.key as keyof typeof groupedTasks].map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    userRole={userRole}
                    onTaskClick={onTaskClick}
                    onStatusChange={onStatusChange}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {filteredTasks.length === 0 && (
        <div className="text-center py-12">
          <Filter className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg mb-2">No tasks found</h3>
          <p className="text-muted-foreground mb-4">
            {searchQuery || statusFilter !== 'all' || priorityFilter !== 'all'
              ? 'Try adjusting your filters or search query.'
              : userRole === 'manager'
              ? 'Get started by creating your first task.'
              : userRole === 'executor'
              ? 'No tasks have been assigned to you yet.'
              : 'No tasks to observe yet.'
            }
          </p>
          {userRole === 'manager' && !searchQuery && statusFilter === 'all' && priorityFilter === 'all' && (
            <Button onClick={onCreateTask}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Task
            </Button>
          )}
        </div>
      )}
    </div>
  );
}