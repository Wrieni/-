import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { 
  Plus, 
  CheckCircle2, 
  Circle, 
  AlertCircle, 
  Clock, 
  Trash2,
  Edit3,
  Save,
  X
} from "lucide-react";

interface Subtask {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed' | 'blocked';
  priority: 'low' | 'medium' | 'high' | 'critical';
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
}

interface SubtaskManagerProps {
  taskId: string;
  subtasks: Subtask[];
  onAddSubtask: (subtask: Omit<Subtask, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => void;
  onUpdateSubtask: (subtaskId: string, updates: Partial<Subtask>) => void;
  onDeleteSubtask: (subtaskId: string) => void;
  userRole: 'manager' | 'executor' | 'observer';
  currentUser: string;
}

const statusIcons = {
  'pending': Circle,
  'in-progress': Clock,
  'completed': CheckCircle2,
  'blocked': AlertCircle
};

const statusColors = {
  'pending': 'bg-gray-100 text-gray-800',
  'in-progress': 'bg-blue-100 text-blue-800',
  'completed': 'bg-green-100 text-green-800',
  'blocked': 'bg-red-100 text-red-800'
};

const priorityColors = {
  'low': 'bg-gray-100 text-gray-700',
  'medium': 'bg-yellow-100 text-yellow-800',
  'high': 'bg-orange-100 text-orange-800',
  'critical': 'bg-red-100 text-red-800'
};

export function SubtaskManager({ 
  taskId, 
  subtasks, 
  onAddSubtask, 
  onUpdateSubtask, 
  onDeleteSubtask, 
  userRole,
  currentUser 
}: SubtaskManagerProps) {
  const [isAddingSubtask, setIsAddingSubtask] = useState(false);
  const [editingSubtaskId, setEditingSubtaskId] = useState<string | null>(null);
  const [newSubtask, setNewSubtask] = useState({
    title: '',
    description: '',
    status: 'pending' as const,
    priority: 'medium' as const
  });

  const [editingSubtask, setEditingSubtask] = useState<Partial<Subtask>>({});

  const canManageSubtasks = userRole === 'executor';

  const handleAddSubtask = () => {
    if (!newSubtask.title.trim()) return;

    onAddSubtask({
      title: newSubtask.title,
      description: newSubtask.description,
      status: newSubtask.status,
      priority: newSubtask.priority
    });

    setNewSubtask({
      title: '',
      description: '',
      status: 'pending',
      priority: 'medium'
    });
    setIsAddingSubtask(false);
  };

  const handleEditSubtask = (subtask: Subtask) => {
    setEditingSubtaskId(subtask.id);
    setEditingSubtask(subtask);
  };

  const handleSaveEdit = () => {
    if (editingSubtaskId && editingSubtask) {
      onUpdateSubtask(editingSubtaskId, editingSubtask);
      setEditingSubtaskId(null);
      setEditingSubtask({});
    }
  };

  const handleCancelEdit = () => {
    setEditingSubtaskId(null);
    setEditingSubtask({});
  };

  const handleStatusChange = (subtaskId: string, newStatus: Subtask['status']) => {
    onUpdateSubtask(subtaskId, { status: newStatus, updatedAt: new Date() });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h3 className="text-lg">Subtasks & Defects</h3>
          <Badge variant="outline">{subtasks.length}</Badge>
        </div>
        {canManageSubtasks && !isAddingSubtask && (
          <Button 
            size="sm" 
            onClick={() => setIsAddingSubtask(true)}
            variant="outline"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Subtask
          </Button>
        )}
      </div>

      {/* Add New Subtask Form */}
      {isAddingSubtask && canManageSubtasks && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Add New Subtask</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="subtask-title">Title *</Label>
              <Input
                id="subtask-title"
                value={newSubtask.title}
                onChange={(e) => setNewSubtask({ ...newSubtask, title: e.target.value })}
                placeholder="Enter subtask title..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="subtask-description">Description</Label>
              <Textarea
                id="subtask-description"
                value={newSubtask.description}
                onChange={(e) => setNewSubtask({ ...newSubtask, description: e.target.value })}
                placeholder="Describe the subtask or defect..."
                className="min-h-[80px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Priority</Label>
                <Select 
                  value={newSubtask.priority} 
                  onValueChange={(value: any) => setNewSubtask({ ...newSubtask, priority: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                <Select 
                  value={newSubtask.status} 
                  onValueChange={(value: any) => setNewSubtask({ ...newSubtask, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="blocked">Blocked</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button 
                variant="outline" 
                onClick={() => setIsAddingSubtask(false)}
                size="sm"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleAddSubtask}
                disabled={!newSubtask.title.trim()}
                size="sm"
              >
                Add Subtask
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Subtasks List */}
      <div className="space-y-3">
        {subtasks.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              <Circle className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>No subtasks created yet</p>
              {canManageSubtasks && (
                <p className="text-sm mt-1">Add subtasks to break down this task into smaller items</p>
              )}
            </CardContent>
          </Card>
        ) : (
          subtasks.map((subtask) => {
            const StatusIcon = statusIcons[subtask.status];
            const isEditing = editingSubtaskId === subtask.id;
            
            return (
              <Card key={subtask.id} className="transition-all hover:shadow-sm">
                <CardContent className="p-4">
                  {isEditing ? (
                    /* Edit Mode */
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Title</Label>
                        <Input
                          value={editingSubtask.title || ''}
                          onChange={(e) => setEditingSubtask({ ...editingSubtask, title: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          value={editingSubtask.description || ''}
                          onChange={(e) => setEditingSubtask({ ...editingSubtask, description: e.target.value })}
                          className="min-h-[60px]"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Priority</Label>
                          <Select 
                            value={editingSubtask.priority || 'medium'} 
                            onValueChange={(value: any) => setEditingSubtask({ ...editingSubtask, priority: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="low">Low</SelectItem>
                              <SelectItem value="medium">Medium</SelectItem>
                              <SelectItem value="high">High</SelectItem>
                              <SelectItem value="critical">Critical</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Status</Label>
                          <Select 
                            value={editingSubtask.status || 'pending'} 
                            onValueChange={(value: any) => setEditingSubtask({ ...editingSubtask, status: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="in-progress">In Progress</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                              <SelectItem value="blocked">Blocked</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={handleCancelEdit}>
                          <X className="h-4 w-4 mr-2" />
                          Cancel
                        </Button>
                        <Button size="sm" onClick={handleSaveEdit}>
                          <Save className="h-4 w-4 mr-2" />
                          Save
                        </Button>
                      </div>
                    </div>
                  ) : (
                    /* View Mode */
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          <StatusIcon className={`h-5 w-5 mt-0.5 ${
                            subtask.status === 'completed' ? 'text-green-600' :
                            subtask.status === 'in-progress' ? 'text-blue-600' :
                            subtask.status === 'blocked' ? 'text-red-600' :
                            'text-gray-400'
                          }`} />
                          <div className="flex-1">
                            <h4 className={`font-medium ${subtask.status === 'completed' ? 'line-through text-muted-foreground' : ''}`}>
                              {subtask.title}
                            </h4>
                            {subtask.description && (
                              <p className="text-sm text-muted-foreground mt-1">
                                {subtask.description}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Badge className={`${statusColors[subtask.status]} text-xs px-2 py-1`}>
                            {subtask.status.replace('-', ' ')}
                          </Badge>
                          <Badge className={`${priorityColors[subtask.priority]} text-xs px-2 py-1`}>
                            {subtask.priority}
                          </Badge>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-5 w-5">
                            <AvatarFallback className="text-xs">
                              {currentUser.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <span>Created {subtask.createdAt.toLocaleDateString()}</span>
                          {subtask.updatedAt && subtask.updatedAt.getTime() !== subtask.createdAt.getTime() && (
                            <span>• Updated {subtask.updatedAt.toLocaleDateString()}</span>
                          )}
                        </div>

                        {canManageSubtasks && (
                          <div className="flex items-center gap-1">
                            {subtask.status !== 'completed' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleStatusChange(subtask.id, 'completed')}
                                className="h-6 px-2 text-xs"
                              >
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Complete
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditSubtask(subtask)}
                              className="h-6 px-2"
                            >
                              <Edit3 className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDeleteSubtask(subtask.id)}
                              className="h-6 px-2 text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {subtasks.length > 0 && (
        <div className="mt-4 p-4 bg-muted/30 rounded-lg">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-lg font-medium text-blue-600">
                {subtasks.filter(s => s.status === 'pending').length}
              </div>
              <div className="text-xs text-muted-foreground">Pending</div>
            </div>
            <div>
              <div className="text-lg font-medium text-yellow-600">
                {subtasks.filter(s => s.status === 'in-progress').length}
              </div>
              <div className="text-xs text-muted-foreground">In Progress</div>
            </div>
            <div>
              <div className="text-lg font-medium text-green-600">
                {subtasks.filter(s => s.status === 'completed').length}
              </div>
              <div className="text-xs text-muted-foreground">Completed</div>
            </div>
            <div>
              <div className="text-lg font-medium text-red-600">
                {subtasks.filter(s => s.status === 'blocked').length}
              </div>
              <div className="text-xs text-muted-foreground">Blocked</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}